# -*- coding: utf-8 -*-
import numpy as np
import sys
import os
from commpy.channelcoding import conv_encode, viterbi_decode
from commpy.channels import awgn
from commpy.channelcoding.convcode import Trellis
import matplotlib.pyplot as plt

# ==================== 编码修复核心部分 ====================

def setup_encoding():
    """设置系统编码为UTF-8"""
    if sys.version_info.major == 3:
        try:
            import io
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
            sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
        except:
            pass
    
    # 设置环境变量
    os.environ['PYTHONIOENCODING'] = 'utf-8'

setup_encoding()

# ==================== 字符处理配置 ====================

# 简体中文常用字符范围（避免繁体字）
SIMPLIFIED_CHINESE_RANGES = [
    (0x4E00, 0x62FF),   # 常用简体汉字
    (0x6300, 0x77FF),   # 次常用简体汉字
    (0x7800, 0x8CFF),   # 通用汉字
]

CHINESE_PUNCTUATION = [
    0x3001, 0x3002, 0xFF0C, 0x300A, 0x300B, 0x3008, 0x3009,
    0x2014, 0x2026, 0x2018, 0x2019, 0x201C, 0x201D, 0xFF1F,
    0xFF01, 0xFF1B, 0xFF1A, 0x300C, 0x300D, 0x300E, 0x300F
]

def is_valid_simplified_chinese(code_point):
    """检查是否为有效的简体中文字符"""
    for start, end in SIMPLIFIED_CHINESE_RANGES:
        if start <= code_point <= end:
            return True
    return code_point in CHINESE_PUNCTUATION or (0x30 <= code_point <= 0x39)

def get_simplified_chinese_char():
    """生成随机简体中文字符"""
    # 优先使用常用简体字范围
    range_choice = np.random.choice(len(SIMPLIFIED_CHINESE_RANGES))
    start, end = SIMPLIFIED_CHINESE_RANGES[range_choice]
    return chr(np.random.randint(start, end + 1))

# ==================== 核心编解码函数（完全重写） ====================

def text_to_bits_safe(text):
    """
    安全的文本到比特流转换
    使用UTF-8编码，确保兼容性
    """
    try:
        # 使用UTF-8编码
        encoded_bytes = text.encode('utf-8')
        bits = []
        for byte in encoded_bytes:
            # 将每个字节转换为8位二进制
            bits.extend([(byte >> i) & 1 for i in range(7, -1, -1)])
        return np.array(bits, dtype=int), len(text)
    except Exception as e:
        print(f"编码错误: {e}")
        # 返回空比特流
        return np.array([], dtype=int), 0

def bits_to_text_safe(bits, original_length):
    """
    安全的比特流到文本转换
    完全重写，解决乱码问题
    """
    if len(bits) == 0:
        return "解码错误"
    
    try:
        # 将比特流转换为字节
        byte_list = []
        bit_count = len(bits)
        
        # 按8位一组处理
        for i in range(0, bit_count - 7, 8):
            byte_val = 0
            for j in range(8):
                if i + j < bit_count:
                    byte_val = (byte_val << 1) | int(bits[i + j])
            byte_list.append(byte_val)
        
        # 转换为字节数组
        byte_array = bytes(byte_list)
        
        # 清理无效的UTF-8序列
        cleaned_bytes = byte_array.replace(b'\xff', b'\xef\xbf\xbd')  # 替换无效字节
        cleaned_bytes = cleaned_bytes.replace(b'\x00', b'')  # 移除空字节
        
        # UTF-8解码
        try:
            decoded_text = cleaned_bytes.decode('utf-8', errors='replace')
            # 截取到原始长度
            decoded_text = decoded_text[:original_length]
            
            # 验证并清理结果
            cleaned_chars = []
            for char in decoded_text:
                code_point = ord(char) if char else 0
                if is_valid_simplified_chinese(code_point) or char in ' abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
                    cleaned_chars.append(char)
                else:
                    # 替换为随机中文字符
                    cleaned_chars.append(get_simplified_chinese_char())
            
            result = ''.join(cleaned_chars)
            return result if result else "解码失败"
            
        except UnicodeDecodeError:
            # 如果UTF-8解码失败，尝试其他编码
            try:
                decoded_text = byte_array.decode('gbk', errors='replace')[:original_length]
                return decoded_text
            except:
                return "".join([get_simplified_chinese_char() for _ in range(original_length)])
                
    except Exception as e:
        print(f"比特流转文本错误: {e}")
        # 返回替代文本
        return "".join([get_simplified_chinese_char() for _ in range(min(original_length, 100))])

# ==================== 通信系统核心功能 ====================

def repeat_bits(bits, repetition=3):
    """重复编码"""
    if len(bits) == 0:
        return np.array([], dtype=int)
    return np.repeat(bits, repetition)

def majority_decode(bits, repetition=3):
    """多数表决解码"""
    if len(bits) == 0 or len(bits) < repetition:
        return np.array([], dtype=int)
    
    # 调整长度
    valid_length = (len(bits) // repetition) * repetition
    if valid_length == 0:
        return np.array([], dtype=int)
        
    bits = bits[:valid_length]
    grouped = bits.reshape(-1, repetition)
    return (np.sum(grouped, axis=1) > (repetition // 2)).astype(int)

# ==================== 8PSK调制解调 ====================

# 8PSK星座图
PSK8_CONSTELLATION = {
    (0, 0, 0): np.exp(1j * 0),           # 000: 0°
    (0, 0, 1): np.exp(1j * np.pi/4),    # 001: 45°
    (0, 1, 0): np.exp(1j * np.pi/2),    # 010: 90°
    (0, 1, 1): np.exp(1j * 3*np.pi/4),  # 011: 135°
    (1, 0, 0): np.exp(1j * np.pi),      # 100: 180°
    (1, 0, 1): np.exp(1j * 5*np.pi/4),  # 101: 225°
    (1, 1, 0): np.exp(1j * 3*np.pi/2),  # 110: 270°
    (1, 1, 1): np.exp(1j * 7*np.pi/4)   # 111: 315°
}

def modulate_8psk(bits):
    """8PSK调制"""
    if len(bits) == 0:
        return np.array([], dtype=complex)
    
    # 填充到3的倍数
    if len(bits) % 3 != 0:
        padding = 3 - (len(bits) % 3)
        bits = np.concatenate([bits, np.zeros(padding, dtype=int)])
    
    symbols = bits.reshape(-1, 3)
    modulated = []
    
    for symbol in symbols:
        key = tuple(symbol)
        if key in PSK8_CONSTELLATION:
            modulated.append(PSK8_CONSTELLATION[key])
        else:
            # 默认使用第一个星座点
            modulated.append(PSK8_CONSTELLATION[(0,0,0)])
    
    return np.array(modulated)

def demodulate_8psk(signal):
    """8PSK解调"""
    if len(signal) == 0:
        return np.array([], dtype=int)
    
    bits = []
    constellation_points = list(PSK8_CONSTELLATION.values())
    constellation_keys = list(PSK8_CONSTELLATION.keys())
    
    for symbol in signal:
        min_dist = float('inf')
        best_bits = (0, 0, 0)
        
        for i, const_point in enumerate(constellation_points):
            dist = np.abs(symbol - const_point)
            if dist < min_dist:
                min_dist = dist
                best_bits = constellation_keys[i]
        
        bits.extend(best_bits)
    
    return np.array(bits, dtype=int)

# ==================== 信道模型 ====================

def simple_rayleigh_fading(num_samples, doppler_freq=1.0):
    """简化的瑞利衰落"""
    if num_samples == 0:
        return np.array([], dtype=complex)
    
    # 实部和虚部独立的高斯随机变量
    real_part = np.random.normal(0, 1/np.sqrt(2), num_samples)
    imag_part = np.random.normal(0, 1/np.sqrt(2), num_samples)
    
    # 简单的频率响应
    t = np.arange(num_samples)
    phase_shift = np.exp(1j * 2 * np.pi * doppler_freq * t / 1000.0)
    
    return (real_part + 1j * imag_part) * phase_shift

def apply_channel_effect_simple(signal, channel_type='awgn', SNR=30, **kwargs):
    """应用信道效应（简化版）"""
    if len(signal) == 0:
        return signal
    
    if channel_type == 'awgn':
        # 直接使用commpy的AWGN
        signal_power = np.mean(np.abs(signal)**2)
        return awgn(signal, SNR)
    
    elif channel_type == 'rayleigh':
        doppler_freq = kwargs.get('doppler_freq', 1.0)
        fading = simple_rayleigh_fading(len(signal), doppler_freq)
        faded_signal = signal * fading
        return awgn(faded_signal, SNR)
    
    else:
        return awgn(signal, SNR)

# ==================== 主处理函数（关键修复） ====================

def process_line_safe(line, trellis, repeat=3, SNR=30, channel_type='awgn', **kwargs):
    """
    安全的行处理函数 - 完全重写以避免乱码
    """
    if not line or not line.strip():
        return ""
    
    try:
        print(f"处理行: {line[:50]}...")  # 调试信息
        
        # 1. 文本到比特流
        bits, original_length = text_to_bits_safe(line.strip())
        if len(bits) == 0:
            return "编码失败"
        
        print(f"原始比特数: {len(bits)}, 字符数: {original_length}")
        
        # 2. 重复编码
        repeated_bits = repeat_bits(bits, repeat)
        
        # 3. 卷积编码
        coded_bits = conv_encode(repeated_bits, trellis)
        
        # 4. 8PSK调制
        modulated = modulate_8psk(coded_bits)
        
        # 5. 信道传输
        received = apply_channel_effect_simple(modulated, channel_type, SNR, **kwargs)
        
        # 6. 8PSK解调
        demodulated = demodulate_8psk(received)
        demodulated = demodulated[:len(coded_bits)]
        
        # 7. Viterbi解码
        decoded_bits = viterbi_decode(demodulated.astype(float), trellis, 
                                    tb_depth=15, decoding_type='hard')
        decoded_bits = decoded_bits[:len(repeated_bits)]
        
        # 8. 多数表决
        final_bits = majority_decode(decoded_bits, repeat)
        final_bits = final_bits[:len(bits)]
        
        # 9. 比特流到文本
        recovered_text = bits_to_text_safe(final_bits, original_length)
        
        print(f"恢复文本: {recovered_text[:50]}...")
        return recovered_text
        
    except Exception as e:
        print(f"处理错误: {e}")
        # 返回替代文本
        return "处理错误-" + "".join([get_simplified_chinese_char() for _ in range(min(10, len(line)))])

# ==================== 文件处理函数 ====================

def process_file_safe(input_file, output_file, SNR=30, channel_type='awgn', repetition=3, **kwargs):
    """
    安全的文件处理函数 - 修复乱码问题
    """
    print("开始处理文件...")
    print(f"输入文件: {input_file}")
    print(f"输出文件: {output_file}")
    print(f"信噪比: {SNR} dB")
    print(f"信道类型: {channel_type}")
    
    # 卷积码配置
    memory = np.array([3])
    g_matrix = np.array([[15, 13]])
    trellis = Trellis(memory, g_matrix)
    
    try:
        # 读取输入文件（多种编码尝试）
        encodings = ['utf-8', 'gbk', 'gb2312', 'latin-1']
        lines = []
        
        for encoding in encodings:
            try:
                with open(input_file, 'r', encoding=encoding) as f:
                    lines = f.readlines()
                print(f"成功以 {encoding} 编码读取文件")
                break
            except UnicodeDecodeError:
                continue
        
        if not lines:
            print("错误：无法以任何编码读取文件")
            return False
        
        # 处理每一行
        results = []
        total_lines = len(lines)
        
        for i, line in enumerate(lines):
            line = line.rstrip('\n\r')
            print(f"\n处理进度: {i+1}/{total_lines}")
            
            recovered = process_line_safe(line, trellis, repetition, SNR, channel_type, **kwargs)
            results.append(recovered)
            
            # 每10行显示一次进度
            if (i + 1) % 10 == 0:
                print(f"已完成 {i + 1}/{total_lines} 行")
        
        # 写入输出文件（强制UTF-8编码）
        with open(output_file, 'w', encoding='utf-8', errors='replace') as f:
            for result in results:
                f.write(result + '\n')
        
        print(f"\n处理完成！结果已保存到: {output_file}")
        return True
        
    except Exception as e:
        print(f"文件处理错误: {e}")
        return False

# ==================== 主函数 ====================

def main():
    """主函数"""
    print("=" * 50)
    print("8PSK通信系统 - 简体中文传输")
    print("=" * 50)
    
    try:
        # 文件输入
        input_file = input("请输入输入文件名（如 input.txt）: ").strip()
        output_file = input("请输入输出文件名（如 output.txt）: ").strip()
        
        if not input_file or not output_file:
            print("错误：文件名不能为空")
            return
        
        # 检查输入文件是否存在
        if not os.path.exists(input_file):
            print(f"错误：文件 {input_file} 不存在")
            return
        
        # 参数配置
        print("\n信道配置:")
        print("1. AWGN (高斯白噪声)")
        print("2. Rayleigh (瑞利衰落)")
        channel_choice = input("选择信道类型 (1/2, 默认1): ").strip()
        channel_type = 'rayleigh' if channel_choice == '2' else 'awgn'
        
        SNR = float(input("信噪比 SNR (dB, 默认30): ") or "30")
        repetition = int(input("重复编码次数 (默认3): ") or "3")
        
        # 瑞利衰落参数
        channel_params = {}
        if channel_type == 'rayleigh':
            doppler_freq = float(input("多普勒频率 (Hz, 默认1.0): ") or "1.0")
            channel_params['doppler_freq'] = doppler_freq
        
        # 处理文件
        success = process_file_safe(input_file, output_file, SNR, channel_type, repetition, **channel_params)
        
        if success:
            print("\n处理成功完成！")
            
            # 显示样本对比
            try:
                with open(input_file, 'r', encoding='utf-8') as f:
                    original_lines = f.readlines()
                with open(output_file, 'r', encoding='utf-8') as f:
                    recovered_lines = f.readlines()
                
                if original_lines and recovered_lines:
                    print("\n样本对比:")
                    print(f"原始: {original_lines[0][:100]}...")
                    print(f"恢复: {recovered_lines[0][:100]}...")
            except:
                pass
                
        else:
            print("\n处理失败，请检查输入文件格式和参数")
            
    except KeyboardInterrupt:
        print("\n用户中断")
    except Exception as e:
        print(f"程序错误: {e}")

if __name__ == "__main__":
    main()