import numpy as np
from commpy.channelcoding import conv_encode, viterbi_decode
from commpy.channels import awgn
from commpy.channelcoding.convcode import Trellis

# 中文常用标点符号Unicode区间
CHINESE_PUNCTUATION = [
    0x3000, 0x3001, 0x3002, 0xFF0C, 0xFF1F, 0xFF01, 0xFF1B, 0xFF1A,
    0xFF08, 0xFF09, 0xFF3B, 0xFF3D, 0x300C, 0x300D, 0x2014, 0x2026,
    0x2018, 0x2019, 0x201C, 0x201D, 0xFF0E, 0xFF0F, 0xFF1D, 0xFF1C,
    0xFF1E, 0xFF20, 0xFF40, 0xFF5E, 0xFF5B, 0xFF5D, 0xFF5F, 0xFF60
]

# 数学符号和相关常用符号的Unicode码
MATH_SYMBOLS = [
    0x2B,   # +
    0x2D,   # -
    0x2E,   # .
    0x2F,   # /
    0x3D,   # =
    0x25,   # %
    0x2212, # −
    0x00D7, # ×
    0x00F7, # ÷
    0x2192, # →
    0x003A, # :
]

def is_chinese_char_or_punct_or_digit_or_math(code_point):
    # 汉字、标点、数字、数学符号，合法性检验
    return (
        (0x4E00 <= code_point <= 0x9FFF) or
        (0x3400 <= code_point <= 0x4DBF) or
        (code_point in CHINESE_PUNCTUATION) or
        (0x30 <= code_point <= 0x39) or
        (code_point in MATH_SYMBOLS)
    )

def get_random_chinese_or_punct_digit_math():
    rand = np.random.rand()
    if rand < 0.10:
        return chr(np.random.choice(CHINESE_PUNCTUATION))
    elif rand < 0.18:
        return chr(np.random.randint(0x30, 0x3a))  # 数字0-9
    elif rand < 0.22:
        return chr(np.random.choice(MATH_SYMBOLS))
    else:
        return chr(np.random.randint(0x4E00, 0x9FFF))

def chinese_to_bits(text):
    #信源编码，将文本按UTF-32编码，并返回比特流和字符数（定长编码，4字节）
    bytes_utf32 = text.encode('utf-32-be')
    bits = []
    for byte in bytes_utf32:
        bits.extend([int(b) for b in format(byte, '08b')])
    return np.array(bits), len(bytes_utf32) // 4

def repeat_bits(bits, repeat=5):
    #信道编码，使用重复码片进行编码
    return np.repeat(bits, repeat)

def majority_vote(bits, repeat=5):
    #重复码片进行解码
    n = len(bits) // repeat
    bits = bits[:n * repeat]
    grouped = bits.reshape(-1, repeat)
    return (np.sum(grouped, axis=1) > (repeat // 2)).astype(int)

def bits_to_chinese_digit_punct_math(bits, num_chars):
    #信源解码，将比特流转换为汉字、标点、数字、数学符号
    chars = []
    for i in range(num_chars):
        char_bits = bits[i*32:(i+1)*32]
        if len(char_bits) < 32:
            continue
        code_point = 0
        for b in char_bits:
            code_point = (code_point << 1) | b
        try:
            if is_chinese_char_or_punct_or_digit_or_math(code_point):
                chars.append(chr(code_point))
            else:
                chars.append(get_random_chinese_or_punct_digit_math())
        except Exception:
            chars.append(get_random_chinese_or_punct_digit_math())
    return ''.join(chars)

# ==================== 新增信道模型功能 ====================

def rayleigh_fading(num_samples, doppler_freq=1):
    """
    生成瑞利衰落信道系数[1,8](@ref)
    :param num_samples: 样本数
    :param doppler_freq: 多普勒频率(Hz)，控制衰落的快慢
    :return: 瑞利衰落信道复数增益
    """
    # 生成独立的实部和虚部高斯随机变量[8](@ref)
    real_part = np.random.normal(0, 1/np.sqrt(2), num_samples)
    imag_part = np.random.normal(0, 1/np.sqrt(2), num_samples)
    
    # 添加多普勒效应（简单的自相关滤波）[8](@ref)
    t = np.arange(num_samples)
    correlation = np.exp(-2 * np.pi * doppler_freq * np.abs(t[:, None] - t))
    real_part = np.dot(correlation, real_part)
    imag_part = np.dot(correlation, imag_part)
    
    # 组合成复数信道增益[1](@ref)
    fading = real_part + 1j * imag_part
    return fading

def rician_fading(num_samples, K_factor=3, doppler_freq=1):
    """
    生成莱斯衰落信道系数[1](@ref)
    :param num_samples: 样本数
    :param K_factor: K因子，表示直射路径和散射路径的功率比
    :param doppler_freq: 多普勒频率(Hz)
    :return: 莱斯衰落信道复数增益
    """
    # 直射路径分量（确定性的）[1](@ref)
    s = np.sqrt(K_factor / (K_factor + 1))
    
    # 散射路径分量（瑞利分布）[1](@ref)
    sigma = np.sqrt(1 / (2 * (K_factor + 1)))
    real_scatter = np.random.normal(0, sigma, num_samples)
    imag_scatter = np.random.normal(0, sigma, num_samples)
    
    # 添加多普勒效应
    t = np.arange(num_samples)
    correlation = np.exp(-2 * np.pi * doppler_freq * np.abs(t[:, None] - t))
    real_scatter = np.dot(correlation, real_scatter)
    imag_scatter = np.dot(correlation, imag_scatter)
    
    # 组合直射路径和散射路径[1](@ref)
    fading = (s + real_scatter) + 1j * imag_scatter
    return fading

def apply_channel_effect(signal, channel_type='awgn', SNR=30, **channel_params):
    """
    应用不同的信道效应到信号上[1,3](@ref)
    :param signal: 输入信号（BPSK调制后的信号）
    :param channel_type: 信道类型 ('awgn', 'rayleigh', 'rician')
    :param SNR: 信噪比(dB)
    :param channel_params: 信道特定参数
    :return: 经过信道后的信号
    """
    if channel_type == 'awgn':
        # 高斯白噪声信道[3](@ref)
        return awgn(signal, SNR)
    
    elif channel_type == 'rayleigh':
        # 瑞利衰落信道[1,8](@ref)
        doppler_freq = channel_params.get('doppler_freq', 1)
        fading_coeff = rayleigh_fading(len(signal), doppler_freq)
        
        # 应用衰落
        faded_signal = signal * fading_coeff
        
        # 添加AWGN噪声[1](@ref)
        return awgn(faded_signal, SNR)
    
    elif channel_type == 'rician':
        # 莱斯衰落信道[1](@ref)
        K_factor = channel_params.get('K_factor', 3)
        doppler_freq = channel_params.get('doppler_freq', 1)
        fading_coeff = rician_fading(len(signal), K_factor, doppler_freq)
        
        # 应用衰落
        faded_signal = signal * fading_coeff
        
        # 添加AWGN噪声
        return awgn(faded_signal, SNR)
    
    else:
        raise ValueError(f"不支持的信道类型: {channel_type}")

def equalize_signal(rx_signal, channel_type, channel_estimation=None):
    """
    信号均衡[1](@ref)
    :param rx_signal: 接收信号
    :param channel_type: 信道类型
    :param channel_estimation: 信道估计值（可选）
    :return: 均衡后的信号
    """
    if channel_type == 'awgn':
        # AWGN信道不需要均衡
        return rx_signal
    
    elif channel_type in ['rayleigh', 'rician']:
        if channel_estimation is None:
            # 简单的幅度均衡（假设信道估计可用）
            return rx_signal / np.mean(np.abs(rx_signal))
        else:
            # 使用信道估计进行均衡[1](@ref)
            return rx_signal / channel_estimation
    
    else:
        return rx_signal

# ==================== 修改处理函数 ====================

def process_line(line, trellis, repeat=5, SNR=30, channel_type='awgn', **channel_params):
    """
    修改后的处理函数，支持多种信道模型
    """
    bits, num_chars = chinese_to_bits(line)
    bits_redundant = repeat_bits(bits, repeat)
    coded_bits = conv_encode(bits_redundant, trellis)
    
    # BPSK调制[7](@ref)
    coded_bits_float = 1 - 2 * coded_bits
    
    # 应用选择的信道模型[1,3](@ref)
    rx_signal = apply_channel_effect(coded_bits_float, channel_type, SNR, **channel_params)
    
    # 均衡处理（针对衰落信道）[1](@ref)
    if channel_type in ['rayleigh', 'rician']:
        rx_signal = equalize_signal(rx_signal, channel_type)
    
    decoded_bits = viterbi_decode(rx_signal, trellis, tb_depth=25, decoding_type='soft')
    decoded_bits = decoded_bits[:len(bits_redundant)]
    recovered_bits = majority_vote(decoded_bits, repeat)
    recovered_text = bits_to_chinese_digit_punct_math(recovered_bits, num_chars)
    return recovered_text

def get_channel_parameters(channel_type):
    """
    获取特定信道类型的参数
    """
    if channel_type == 'rayleigh':
        print("\n瑞利信道参数配置:")
        doppler_freq = float(input("请输入多普勒频率(Hz，默认1.0): ") or "1.0")
        return {'doppler_freq': doppler_freq}
    
    elif channel_type == 'rician':
        print("\n莱斯信道参数配置:")
        K_factor = float(input("请输入K因子(直射路径功率比，默认3.0): ") or "3.0")
        doppler_freq = float(input("请输入多普勒频率(Hz，默认1.0): ") or "1.0")
        return {'K_factor': K_factor, 'doppler_freq': doppler_freq}
    
    else:
        return {}

def main():
    input_file = input("请输入待处理txt文件名（如input.txt）：").strip()
    output_file = input("请输入输出txt文件名（如output.txt）：").strip()
    
    # 信道类型选择
    print("\n请选择信道模型:")
    print("1. 高斯白噪声信道(AWGN)")
    print("2. 瑞利衰落信道(Rayleigh)")
    print("3. 莱斯衰落信道(Rician)")
    
    channel_choice = input("请输入选择(1/2/3，默认1): ").strip() or "1"
    
    channel_map = {'1': 'awgn', '2': 'rayleigh', '3': 'rician'}
    channel_type = channel_map.get(channel_choice, 'awgn')
    
    # 获取信道参数
    channel_params = get_channel_parameters(channel_type)
    
    # SNR设置
    SNR = float(input("请输入信噪比SNR(dB，默认30): ") or "30")
    
    # 重复次数
    repeat = int(input("请输入重复码次数(默认5): ") or "5")

    # 卷积码参数
    memory = np.array([3])
    g_matrix = np.array([[15, 13]])
    trellis = Trellis(memory, g_matrix)

    print(f"\n开始处理...")
    print(f"信道类型: {channel_type}")
    print(f"信噪比: {SNR} dB")
    print(f"信道参数: {channel_params}")

    with open(input_file, "r", encoding="utf-8") as fin, open(output_file, "w", encoding="utf-8") as fout:
        for i, line in enumerate(fin):
            line = line.rstrip('\n\r')
            if not line.strip():
                fout.write('\n')
                continue
            
            recovered = process_line(line, trellis, repeat=repeat, SNR=SNR, 
                                   channel_type=channel_type, **channel_params)
            fout.write(recovered + '\n')
            
            # 进度显示
            if i % 10 == 0:
                print(f"已处理 {i} 行...")

    print(f"处理完成！恢复文本已保存到 {output_file}")

if __name__ == "__main__":
    main()