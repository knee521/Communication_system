.. automodule:: commpy.modulation
    :members:
