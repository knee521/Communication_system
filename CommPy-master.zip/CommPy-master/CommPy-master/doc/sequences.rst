.. automodule:: commpy.sequences
