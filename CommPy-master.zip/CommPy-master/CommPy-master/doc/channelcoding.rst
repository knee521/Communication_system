.. automodule:: commpy.channelcoding
	:members:
	:noindex:
